(function() {var implementors = {};
implementors["svg"] = [{text:"impl <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/std/error/trait.Error.html\" title=\"trait std::error::Error\">Error</a> for <a class=\"struct\" href=\"svg/parser/struct.Error.html\" title=\"struct svg::parser::Error\">Error</a>",synthetic:false,types:["svg::parser::error::Error"]},];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
