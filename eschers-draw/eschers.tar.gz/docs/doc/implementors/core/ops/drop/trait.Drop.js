(function() {var implementors = {};
implementors["itertools"] = [{text:"impl&lt;'a, K, I, F&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/ops/drop/trait.Drop.html\" title=\"trait core::ops::drop::Drop\">Drop</a> for <a class=\"struct\" href=\"itertools/structs/struct.Group.html\" title=\"struct itertools::structs::Group\">Group</a>&lt;'a, K, I, F&gt; <span class=\"where fmt-newline\">where<br>&nbsp;&nbsp;&nbsp;&nbsp;I: <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/iter/iterator/trait.Iterator.html\" title=\"trait core::iter::iterator::Iterator\">Iterator</a>,<br>&nbsp;&nbsp;&nbsp;&nbsp;I::<a class=\"type\" href=\"https://doc.rust-lang.org/nightly/core/iter/iterator/trait.Iterator.html#associatedtype.Item\" title=\"type core::iter::iterator::Iterator::Item\">Item</a>: 'a,&nbsp;</span>",synthetic:false,types:["itertools::groupbylazy::Group"]},{text:"impl&lt;'a, I&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/ops/drop/trait.Drop.html\" title=\"trait core::ops::drop::Drop\">Drop</a> for <a class=\"struct\" href=\"itertools/structs/struct.Chunk.html\" title=\"struct itertools::structs::Chunk\">Chunk</a>&lt;'a, I&gt; <span class=\"where fmt-newline\">where<br>&nbsp;&nbsp;&nbsp;&nbsp;I: <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/iter/iterator/trait.Iterator.html\" title=\"trait core::iter::iterator::Iterator\">Iterator</a>,<br>&nbsp;&nbsp;&nbsp;&nbsp;I::<a class=\"type\" href=\"https://doc.rust-lang.org/nightly/core/iter/iterator/trait.Iterator.html#associatedtype.Item\" title=\"type core::iter::iterator::Iterator::Item\">Item</a>: 'a,&nbsp;</span>",synthetic:false,types:["itertools::groupbylazy::Chunk"]},];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
