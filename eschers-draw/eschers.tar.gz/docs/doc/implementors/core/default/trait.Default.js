(function() {var implementors = {};
implementors["svg"] = [{text:"impl <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/default/trait.Default.html\" title=\"trait core::default::Default\">Default</a> for <a class=\"struct\" href=\"svg/node/element/path/struct.Data.html\" title=\"struct svg::node::element::path::Data\">Data</a>",synthetic:false,types:["svg::node::element::path::data::Data"]},];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
